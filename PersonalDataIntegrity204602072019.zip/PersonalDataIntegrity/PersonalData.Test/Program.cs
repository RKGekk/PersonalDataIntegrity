﻿using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Storage;
using PersonalData.Repository;
using System;
using System.Linq;

namespace PersonalData.Test {
    class Program {
        static void Main(string[] args) {
            Console.WriteLine("Hello World!");
            bool nn = WipeCreateSeed(false);
        }

        public static bool WipeCreateSeed(bool onlyIfNoDatabase) {

            var r_ContextFactory = new PersonalData_ContextFactory();

            using (var db = r_ContextFactory.CreateDbContext(null)) {
                if (onlyIfNoDatabase && (db.GetService<IDatabaseCreator>() as RelationalDatabaseCreator).Exists())
                    return false;

                db.Database.EnsureDeleted();
                db.Database.EnsureCreated();

                if (!db.TypeDigests.Any()) {
                    PersonalData_Initializer context_Initializer = new PersonalData_Initializer(db);
                    Console.WriteLine("Seeded database");
                }
            }
            return true;
        }
    }
}

﻿using System;

namespace PersonalDataIntegrity {
    public class Class1 {
    }
}

﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using PersonalData.Repository.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace PersonalData.Repository.Configuration {

    public class OperationArgumentListConfig : IEntityTypeConfiguration<OperationArgumentList> {

        public void Configure(EntityTypeBuilder<OperationArgumentList> builder) {

            builder.ToTable("rlOperationArgumentList");
            builder.HasKey(c => c.Id);

            builder.HasOne(c => c.ExpressionArgument).WithMany(c => c.OperationArgumentList).HasForeignKey(c => c.ExpressionArgumentId).OnDelete(DeleteBehavior.Restrict);
            builder.HasOne(c => c.ExpressionOperation).WithMany(c => c.OperationArgumentList).HasForeignKey(c => c.ExpressionOperationId).OnDelete(DeleteBehavior.Restrict);

            builder.Property(c => c.Id).IsRequired().HasColumnName("idrlOperationArgumentList");
            builder.Property(c => c.ArgumentSequence).IsRequired().HasColumnName("iArgumentSequence");
            builder.Property(c => c.ArgumentName).IsRequired().HasColumnName("sArgumentName");
            builder.Property(c => c.ExpressionArgumentId).IsRequired().HasColumnName("idExpressionArgument");
            builder.Property(c => c.ExpressionOperationId).IsRequired().HasColumnName("idExpressionOperation");
        }
    }
}

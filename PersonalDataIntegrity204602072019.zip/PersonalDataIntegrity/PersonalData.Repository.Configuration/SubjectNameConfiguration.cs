﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using PersonalData.Repository.Models.Objects;
using System;
using System.Collections.Generic;
using System.Text;

namespace PersonalData.Repository.Configuration {

    public class SubjectNameConfiguration : IEntityTypeConfiguration<SubjectName> {

        public void Configure(EntityTypeBuilder<SubjectName> builder) {

            builder.ToTable("ftSubjectName");
            builder.HasKey(c => c.Id);

            builder.HasOne(c => c.Subject).WithMany(c => c.SubjectNames).HasForeignKey(c => c.SubjectId).OnDelete(DeleteBehavior.Restrict);
            builder.HasOne(c => c.NameType).WithMany(c => c.SubjectName_SubjectNameTypes).HasForeignKey(c => c.NameTypeId).OnDelete(DeleteBehavior.Restrict);

            builder.Property(c => c.Id).IsRequired().HasColumnName("idSubjectName");
            builder.Property(c => c.NameTypeId).HasColumnName("idNameType");
            builder.Property(c => c.OrderInSequence).IsRequired().HasColumnName("iSequence");
            builder.Property(c => c.SubjectId).HasColumnName("idSubject");
            builder.Property(c => c.Name).IsRequired().HasColumnName("sName");
            builder.Property(c => c.From).HasColumnName("dFrom");
            builder.Property(c => c.Thru).HasColumnName("dThru");
        }
    }
}

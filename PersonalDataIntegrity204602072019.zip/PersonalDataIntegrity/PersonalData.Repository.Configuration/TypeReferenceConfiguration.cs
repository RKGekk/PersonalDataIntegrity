﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using PersonalData.Repository.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace PersonalData.Repository.Configuration {

    public class TypeReferenceConfiguration : IEntityTypeConfiguration<TypeReference> {

        public void Configure(EntityTypeBuilder<TypeReference> builder) {

            builder.ToTable("ftTypeReferences");
            builder.HasKey(c => c.Id);

            builder.HasOne(c => c.Reference).WithOne(c => c.TypeReference).OnDelete(DeleteBehavior.Restrict);
            builder.HasOne(c => c.TypeReferenceType).WithMany(c => c.TypeReference_TypeReferences).HasForeignKey(c => c.TypeReferenceTypeId).OnDelete(DeleteBehavior.Restrict);

            builder.Property(c => c.Id).HasColumnName("idTypeReference").IsRequired();
            builder.Property(c => c.TypeReferenceTypeId).HasColumnName("idTypeReferenceType").IsRequired();
        }
    }
}

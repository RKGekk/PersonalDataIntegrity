﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using PersonalData.Repository.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace PersonalData.Repository.Configuration {

    public class ConstReferenceConfiguration : IEntityTypeConfiguration<ConstReference> {

        public void Configure(EntityTypeBuilder<ConstReference> builder) {

            builder.ToTable("ftConstReferences");
            builder.HasKey(c => c.Id);

            builder.HasOne(c => c.Reference).WithOne(c => c.ConstReference).OnDelete(DeleteBehavior.Restrict);
            builder.HasOne(c => c.ConstantReferenceType).WithMany(c => c.ConstReference_ConstantReferenceTypes).HasForeignKey(c => c.ConstantReferenceTypeId).OnDelete(DeleteBehavior.Restrict);

            builder.Property(c => c.Id).IsRequired().HasColumnName("idConstReference");
            builder.Property(c => c.ConstantReferenceTypeId).HasColumnName("idConstantReferenceType");
            builder.Property(c => c.ValueString).HasColumnName("sValue");
            builder.Property(c => c.ValueInt).HasColumnName("iValue");
            builder.Property(c => c.ValueDouble).HasColumnName("fValue");
            builder.Property(c => c.ValueBoolean).HasColumnName("bValue");
        }
    }
}

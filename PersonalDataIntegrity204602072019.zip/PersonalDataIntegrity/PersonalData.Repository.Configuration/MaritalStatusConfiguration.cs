﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using PersonalData.Repository.Models.Objects;
using System;
using System.Collections.Generic;
using System.Text;

namespace PersonalData.Repository.Configuration {

    public class MaritalStatusConfiguration : IEntityTypeConfiguration<MaritalStatus> {

        public void Configure(EntityTypeBuilder<MaritalStatus> builder) {

            builder.ToTable("ftMaritalStatus");
            builder.HasKey(c => c.Id);

            builder.HasOne(c => c.MaritalStatusType).WithMany(c => c.MaritalStatus_MaritalStatusTypes).HasForeignKey(c => c.MaritalTypeId).OnDelete(DeleteBehavior.Restrict);
            builder.HasOne(c => c.Person).WithMany(c => c.MaritalStatuses).HasForeignKey(c => c.PersonId).OnDelete(DeleteBehavior.Restrict);

            builder.Property(c => c.Id).IsRequired().HasColumnName("idMaritalStatus");
            builder.Property(c => c.MaritalTypeId).HasColumnName("idMaritalStatusType");
            builder.Property(c => c.PersonId).HasColumnName("idPerson");
            builder.Property(c => c.From).HasColumnName("dFrom");
            builder.Property(c => c.Thru).HasColumnName("dThru");
        }
    }
}

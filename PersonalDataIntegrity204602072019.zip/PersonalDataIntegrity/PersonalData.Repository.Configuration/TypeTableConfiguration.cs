﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using PersonalData.Repository.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace PersonalData.Repository.Configuration {

    public class TypeTableConfiguration : IEntityTypeConfiguration<TypeTable> {

        public void Configure(EntityTypeBuilder<TypeTable> builder) {

            builder.ToTable("drTypeTable");
            builder.HasKey(c => c.Id);

            builder.HasMany(c => c.TypeCategories).WithOne(c => c.TypeTable).HasForeignKey(c => c.TypeTableId);
            builder.HasMany(c => c.TypeDigests).WithOne(c => c.TypeTable).HasForeignKey(c => c.TypeTableId);

            builder.Property(c => c.Id).IsRequired().HasColumnName("idTypeTable");
            builder.Property(c => c.Table).HasMaxLength(50).HasColumnName("sTable");
            builder.Property(c => c.Name).HasMaxLength(100).HasColumnName("sName");
            builder.Property(c => c.Name).HasMaxLength(100).HasColumnName("sNote");
            builder.Property(c => c.PK).HasMaxLength(256).HasColumnName("sPK");
            builder.Property(c => c.TableObjectId).HasColumnName("idTableObject");
        }
    }
}

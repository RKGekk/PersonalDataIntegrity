﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using PersonalData.Repository.Models.Objects;
using System;
using System.Collections.Generic;
using System.Text;

namespace PersonalData.Repository.Configuration {

    public class SubjectRoleConfiguration : IEntityTypeConfiguration<SubjectRole> {

        public void Configure(EntityTypeBuilder<SubjectRole> builder) {

            builder.ToTable("ftSubjectRole");
            builder.HasKey(c => c.Id);

            builder.HasOne(c => c.WebContentRole).WithOne(c => c.BaseSubjectRole).HasForeignKey<SubjectRole>(c => c.Id).OnDelete(DeleteBehavior.Restrict);
            builder.HasOne(c => c.Subject).WithMany(c => c.SubjectRoles).HasForeignKey(c => c.SubjectId).OnDelete(DeleteBehavior.Restrict);
            builder.HasMany(c => c.SubjectRolesFrom).WithOne(c => c.FromSubjectRole).HasForeignKey(c => c.FromRoleId).OnDelete(DeleteBehavior.Restrict);
            builder.HasMany(c => c.SubjectRolesTo).WithOne(c => c.ToSubjectRole).HasForeignKey(c => c.ToRoleId).OnDelete(DeleteBehavior.Restrict);

            builder.Property(c => c.Id).IsRequired().HasColumnName("idSubjectRole");
            builder.Property(c => c.RoleTypeId).HasColumnName("idRoleType");
            builder.Property(c => c.SubjectId).IsRequired().HasColumnName("idSubject");
            builder.Property(c => c.From).HasColumnName("dFrom");
            builder.Property(c => c.Thru).HasColumnName("dThru");
        }
    }
}
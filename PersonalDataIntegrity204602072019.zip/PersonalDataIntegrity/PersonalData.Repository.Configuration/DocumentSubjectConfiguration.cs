﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using PersonalData.Repository.Models.Objects;
using System;
using System.Collections.Generic;
using System.Text;

namespace PersonalData.Repository.Configuration {

    public class DocumentSubjectConfiguration : IEntityTypeConfiguration<DocumentSubject> {

        public void Configure(EntityTypeBuilder<DocumentSubject> builder) {

            builder.ToTable("rlDocumentSubject");
            builder.HasKey(c => c.Id);

            builder.HasOne(c => c.RelationType).WithMany(c => c.DocumentSubject_RelationTypes).HasForeignKey(c => c.RelationTypeId).OnDelete(DeleteBehavior.Restrict);
            builder.HasOne(c => c.Document).WithMany(c => c.DocumentSubjects).HasForeignKey(c => c.DocumentId).OnDelete(DeleteBehavior.Restrict);
            builder.HasOne(c => c.Subject).WithMany(c => c.DocumentSubjects).HasForeignKey(c => c.SubjectId).OnDelete(DeleteBehavior.Restrict);

            builder.Property(c => c.Id).IsRequired().HasColumnName("idrlDocumentSubject");
            builder.Property(c => c.RelationTypeId).HasColumnName("idrlType");
            builder.Property(c => c.DocumentId).HasColumnName("idDocument");
            builder.Property(c => c.SubjectId).HasColumnName("idSubject");
            builder.Property(c => c.From).HasColumnName("dFrom");
            builder.Property(c => c.Thru).HasColumnName("dThru");
        }
    }
}

﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using PersonalData.Repository.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace PersonalData.Repository.Configuration {

    public class OperationNodeConfiguration : IEntityTypeConfiguration<OperationNode> {

        public void Configure(EntityTypeBuilder<OperationNode> builder) {

            builder.ToTable("ftOperationNodes");
            builder.HasKey(c => c.Id);

            builder.HasOne(c => c.ExpressionNode).WithOne(c => c.OperationNode).OnDelete(DeleteBehavior.Restrict);
            builder.HasMany(c => c.OperationArgumentList).WithOne(c => c.ExpressionOperation).OnDelete(DeleteBehavior.Restrict);
            builder.HasOne(c => c.OperationNodeType).WithMany(c => c.OperationNode_OperationNodeTypes).HasForeignKey(c => c.OperationNodeTypeId).OnDelete(DeleteBehavior.Restrict);

            builder.Property(c => c.Id).IsRequired().HasColumnName("idOperationNode");
            builder.Property(c => c.OperationNodeTypeId).IsRequired().HasColumnName("idOperationNodeType");
        }
    }
}

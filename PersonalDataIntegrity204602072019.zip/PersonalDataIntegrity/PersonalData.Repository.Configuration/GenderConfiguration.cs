﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using PersonalData.Repository.Models.Objects;
using System;
using System.Collections.Generic;
using System.Text;

namespace PersonalData.Repository.Configuration {

    public class GenderConfiguration : IEntityTypeConfiguration<Gender> {

        public void Configure(EntityTypeBuilder<Gender> builder) {

            builder.ToTable("ftGender");
            builder.HasKey(c => c.Id);

            builder.HasOne(c => c.GenderType).WithMany(c => c.Gender_GenderTypes).HasForeignKey(c => c.GenderTypeId).OnDelete(DeleteBehavior.Restrict);
            builder.HasOne(c => c.Person).WithMany(c => c.Genders).HasForeignKey(c => c.PersonId).OnDelete(DeleteBehavior.Restrict);

            builder.Property(c => c.Id).IsRequired().HasColumnName("idGender");
            builder.Property(c => c.GenderTypeId).HasColumnName("idGenderType");
            builder.Property(c => c.PersonId).HasColumnName("idPerson");
            builder.Property(c => c.From).HasColumnName("dFrom");
            builder.Property(c => c.Thru).HasColumnName("dThru");
        }
    }
}

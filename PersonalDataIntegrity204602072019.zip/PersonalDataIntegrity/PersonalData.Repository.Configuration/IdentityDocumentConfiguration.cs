﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using PersonalData.Repository.Models.Objects;
using System;
using System.Collections.Generic;
using System.Text;

namespace PersonalData.Repository.Configuration {

    public class IdentityDocumentConfiguration : IEntityTypeConfiguration<IdentityDocument> {

        public void Configure(EntityTypeBuilder<IdentityDocument> builder) {

            builder.ToTable("ftDocument");
            builder.HasKey(c => c.Id);

            builder.HasMany(c => c.DocumentSubjects).WithOne(c => c.Document).HasForeignKey(c => c.DocumentId).OnDelete(DeleteBehavior.Restrict);
            builder.HasOne(c => c.DocumentType).WithMany(c => c.IdentityDocument_DocumentTypes).HasForeignKey(c => c.DocumentTypeId).OnDelete(DeleteBehavior.Restrict);

            builder.Property(c => c.Id).IsRequired().HasColumnName("idDocument");
            builder.Property(c => c.Name).HasColumnName("sName");
            builder.Property(c => c.DocumentTypeId).HasColumnName("idDocumentType");
            builder.Property(c => c.DocumentNumber).HasColumnName("sNumber");
            builder.Property(c => c.IssueDate).HasColumnName("dIssueDate");
            builder.Property(c => c.ExpirationDate).HasColumnName("dExpirationDate");
        }
    }
}

﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using PersonalData.Repository.Models.Objects;
using System;
using System.Collections.Generic;
using System.Text;

namespace PersonalData.Repository.Configuration {

    public class PhysicalCharacteristicConfiguration : IEntityTypeConfiguration<PhysicalCharacteristic> {

        public void Configure(EntityTypeBuilder<PhysicalCharacteristic> builder) {

            builder.ToTable("ftPhysicalCharacteristic");
            builder.HasKey(c => c.Id);

            builder.HasOne(c => c.PhysicalCharacteristicType).WithMany(c => c.PhysicalCharacteristic_PhysicalCharacteristicTypes).HasForeignKey(c => c.PhysicalCharacteristicType).OnDelete(DeleteBehavior.Restrict);
            builder.HasOne(c => c.Person).WithMany(c => c.PhysicalCharacteristics).HasForeignKey(c => c.PersonId).OnDelete(DeleteBehavior.Restrict);

            builder.Property(c => c.Id).IsRequired().HasColumnName("idPhysicalCharacteristic");
            builder.Property(c => c.PhysicalValueTypeId).HasColumnName("idPhysicalCharacteristicType");
            builder.Property(c => c.PersonId).HasColumnName("idPerson");
            builder.Property(c => c.PhysicalValue).HasColumnName("sValue");
            builder.Property(c => c.From).HasColumnName("dFrom");
            builder.Property(c => c.Thru).HasColumnName("dThru");
        }
    }
}

﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using PersonalData.Repository.Models.Objects;
using System;
using System.Collections.Generic;
using System.Text;

namespace PersonalData.Repository.Configuration {

    public class PersonConfiguration : IEntityTypeConfiguration<Person> {

        public void Configure(EntityTypeBuilder<Person> builder) {

            builder.ToTable("ftPerson");
            builder.HasKey(c => c.Id);

            builder.HasOne(c => c.BaseSubject).WithOne(c => c.Person).OnDelete(DeleteBehavior.Restrict);
            builder.HasMany(c => c.MaritalStatuses).WithOne(c => c.Person).HasForeignKey(c => c.PersonId).OnDelete(DeleteBehavior.Restrict);
            builder.HasMany(c => c.Genders).WithOne(c => c.Person).HasForeignKey(c => c.PersonId).OnDelete(DeleteBehavior.Restrict);
            builder.HasMany(c => c.PhysicalCharacteristics).WithOne(c => c.Person).HasForeignKey(c => c.PersonId).OnDelete(DeleteBehavior.Restrict);

            builder.Property(c => c.Id).IsRequired().HasColumnName("idPerson");
            builder.Property(c => c.BirthDate).HasColumnName("dBirthDate");
            builder.Property(c => c.Comment).HasColumnName("sComment");
        }
    }
}

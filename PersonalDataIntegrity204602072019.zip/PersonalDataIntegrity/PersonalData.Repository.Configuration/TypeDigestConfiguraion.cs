﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using PersonalData.Repository.Models;
//using PersonalData.Repository.Models.Objects;
using System;
using System.Collections.Generic;
using System.Text;

namespace PersonalData.Repository.Configuration {

    public class TypeDigestConfiguraion : IEntityTypeConfiguration<TypeDigest> {

        public void Configure(EntityTypeBuilder<TypeDigest> builder) {

            builder.ToTable("drType");
            builder.HasKey(c => c.Id);

            builder.HasOne(c => c.TypeCategoryBase).WithOne(c => c.TypeDigest).HasForeignKey<TypeCategory>(c => c.Id).OnDelete(DeleteBehavior.Restrict);
            builder.HasOne(c => c.TypeRelationBase).WithOne(c => c.BaseTypeDigest).HasForeignKey<TypeDigestRelation>(c => c.Id).OnDelete(DeleteBehavior.Restrict);
            builder.HasOne(c => c.Category).WithMany(c => c.TypeDigests).HasForeignKey(c => c.TypeCategoryId);
            builder.HasOne(c => c.ParentType).WithMany(c => c.ChildTypes).HasForeignKey(c => c.ParentId);
            builder.HasMany(c => c.ChildTypes).WithOne(c => c.ParentType).HasForeignKey(c => c.ParentId);
            builder.HasMany(c => c.TypeDigestRelation_TypeDigest1).WithOne(c => c.TypeDigest1).HasForeignKey(c => c.Type1Id).OnDelete(DeleteBehavior.Restrict);
            builder.HasMany(c => c.TypeDigestRelation_TypeDigest2).WithOne(c => c.TypeDigest2).HasForeignKey(c => c.Type2Id).OnDelete(DeleteBehavior.Restrict);
            builder.HasOne(c => c.TypeTable).WithMany(c => c.TypeDigests).HasForeignKey(c => c.TypeTableId);

            builder.HasMany(c => c.ExpressionNode_ExpressionNodeTypes).WithOne(c => c.ExpressionNodeType).HasForeignKey(c => c.ExpressionNodeTypeId).OnDelete(DeleteBehavior.Restrict);
            builder.HasMany(c => c.Reference_ReferenceTypes).WithOne(c => c.ReferenceType).HasForeignKey(c => c.ReferenceTypeId).OnDelete(DeleteBehavior.Restrict);
            builder.HasMany(c => c.TypeReference_TypeReferences).WithOne(c => c.TypeReferenceType).HasForeignKey(c => c.TypeReferenceTypeId).OnDelete(DeleteBehavior.Restrict);
            builder.HasMany(c => c.ConstReference_ConstantReferenceTypes).WithOne(c => c.ConstantReferenceType).HasForeignKey(c => c.ConstantReferenceTypeId).OnDelete(DeleteBehavior.Restrict);
            builder.HasMany(c => c.OperationNode_OperationNodeTypes).WithOne(c => c.OperationNodeType).HasForeignKey(c => c.OperationNodeTypeId).OnDelete(DeleteBehavior.Restrict);

            builder.Property(c => c.Id).HasColumnName("idType").IsRequired();
            builder.Property(c => c.ParentId).HasColumnName("idParent");
            builder.Property(c => c.TypeCategoryId).HasColumnName("idTypeCategory");
            builder.Property(c => c.Code).HasColumnName("sCode").IsUnicode(false).HasMaxLength(100).IsRequired();
            builder.Property(c => c.BCode).HasColumnName("sBCode").HasMaxLength(100);
            builder.Property(c => c.Name).HasColumnName("sName").HasMaxLength(150);
            builder.Property(c => c.TypeTableId).HasColumnName("idTypeTable");
            builder.Property(c => c.Note).HasColumnName("sNote"); //должно быть HasMaxLength(1255), но некоторые строки не укладываются в это ограничение при инициализации
            builder.Property(c => c.Edit).HasColumnName("dEdit").IsRequired().HasColumnType("DATETIME");
            builder.Property(c => c.Open).HasColumnName("dOpen").IsRequired().HasColumnType("DATETIME");
            builder.Property(c => c.Close).HasColumnName("dClose").IsRequired().HasColumnType("DATETIME");
            builder.Property(c => c.Order).HasColumnName("iOrder").IsRequired();

            builder.HasIndex(p => p.Code).IsUnique();
        }
    }
}

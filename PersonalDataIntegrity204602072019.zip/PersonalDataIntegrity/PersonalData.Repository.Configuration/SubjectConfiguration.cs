﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using PersonalData.Repository.Models.Objects;
using System;
using System.Collections.Generic;
using System.Text;

namespace PersonalData.Repository.Configuration {

    public class SubjectConfiguration : IEntityTypeConfiguration<Subject> {

        public void Configure(EntityTypeBuilder<Subject> builder) {

            builder.ToTable("ftSubject");
            builder.HasKey(c => c.Id);

            builder.HasOne(c => c.Organization).WithOne(c => c.BaseSubject).HasForeignKey<Organization>(c => c.Id).OnDelete(DeleteBehavior.Restrict);
            builder.HasOne(c => c.Person).WithOne(c => c.BaseSubject).HasForeignKey<Person>(c => c.Id).OnDelete(DeleteBehavior.Restrict);

            builder.HasMany(c => c.DocumentSubjects).WithOne(c => c.Subject).HasForeignKey(c => c.SubjectId).OnDelete(DeleteBehavior.Restrict);
            builder.HasMany(c => c.UserLogins).WithOne(c => c.Subject).HasForeignKey(c => c.SubjectId).OnDelete(DeleteBehavior.Restrict);
            builder.HasMany(c => c.SubjectRoles).WithOne(c => c.Subject).HasForeignKey(c => c.SubjectId).OnDelete(DeleteBehavior.Restrict);
            builder.HasMany(c => c.SubjectNames).WithOne(c => c.Subject).HasForeignKey(c => c.SubjectId).OnDelete(DeleteBehavior.Restrict);

            builder.HasOne(c => c.SubjectType).WithMany(c => c.Subject_SubjectTypes).HasForeignKey(c => c.SubjectTypeId).OnDelete(DeleteBehavior.Restrict);

            builder.Property(c => c.Id).IsRequired().HasColumnName("idSubject");
            builder.Property(c => c.SubjectTypeId).HasColumnName("idSubjectType");
        }
    }
}

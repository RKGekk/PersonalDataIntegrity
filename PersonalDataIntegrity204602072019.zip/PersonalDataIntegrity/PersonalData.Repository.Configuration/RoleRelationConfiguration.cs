﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using PersonalData.Repository.Models.Objects;
using System;
using System.Collections.Generic;
using System.Text;

namespace PersonalData.Repository.Configuration {

    public class RoleRelationConfiguration : IEntityTypeConfiguration<RoleRelation> {

        public void Configure(EntityTypeBuilder<RoleRelation> builder) {

            builder.ToTable("rlRole");
            builder.HasKey(c => c.Id);

            builder.HasOne(c => c.RelationType).WithMany(c => c.RoleRelation_RelationTypes).HasForeignKey(c => c.RelationTypeId).OnDelete(DeleteBehavior.Restrict);
            builder.HasOne(c => c.FromSubjectRole).WithMany(c => c.SubjectRolesFrom).HasForeignKey(c => c.FromRoleId).OnDelete(DeleteBehavior.Restrict);
            builder.HasOne(c => c.ToSubjectRole).WithMany(c => c.SubjectRolesTo).HasForeignKey(c => c.ToRoleId).OnDelete(DeleteBehavior.Restrict);

            builder.Property(c => c.Id).IsRequired().HasColumnName("idrlRole");
            builder.Property(c => c.RelationTypeId).HasColumnName("idrlType");
            builder.Property(c => c.FromRoleId).HasColumnName("idFromRole");
            builder.Property(c => c.ToRoleId).HasColumnName("idToRole");
            builder.Property(c => c.From).HasColumnName("dFrom");
            builder.Property(c => c.Thru).HasColumnName("dThru");
        }
    }
}

﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using PersonalData.Repository.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace PersonalData.Repository.Configuration {

    public class TypeDigestRelationConfiguration : IEntityTypeConfiguration<TypeDigestRelation> {

        public void Configure(EntityTypeBuilder<TypeDigestRelation> builder) {

            builder.ToTable("rlType");
            builder.HasKey(c => c.Id);

            builder.HasOne(c => c.BaseTypeDigest).WithOne(c => c.TypeRelationBase).OnDelete(DeleteBehavior.Restrict);
            builder.HasOne(c => c.TypeDigest1).WithMany(c => c.TypeDigestRelation_TypeDigest1).HasForeignKey(c => c.Type1Id).OnDelete(DeleteBehavior.Restrict);
            builder.HasOne(c => c.TypeDigest2).WithMany(c => c.TypeDigestRelation_TypeDigest2).HasForeignKey(c => c.Type2Id).OnDelete(DeleteBehavior.Restrict);

            builder.Property(c => c.Id).IsRequired().HasColumnName("idrlType");
            builder.Property(c => c.Type1Id).HasColumnName("idType1");
            builder.Property(c => c.Type2Id).HasColumnName("idType2");
        }
    }
}

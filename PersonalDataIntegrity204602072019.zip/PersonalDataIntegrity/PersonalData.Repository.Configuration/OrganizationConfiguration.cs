﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using PersonalData.Repository.Models.Objects;
using System;
using System.Collections.Generic;
using System.Text;

namespace PersonalData.Repository.Configuration {

    public class OrganizationConfiguration : IEntityTypeConfiguration<Organization> {

        public void Configure(EntityTypeBuilder<Organization> builder) {

            builder.ToTable("ftOrganization");
            builder.HasKey(c => c.Id);

            builder.HasOne(c => c.BaseSubject).WithOne(c => c.Organization).OnDelete(DeleteBehavior.Restrict);
            builder.HasOne(c => c.OrganizationType).WithMany(c => c.Organization_OrganizationTypes).HasForeignKey(c => c.OrganizationTypeId).OnDelete(DeleteBehavior.Restrict);

            builder.Property(c => c.Id).IsRequired().HasColumnName("idOrganization");
            builder.Property(c => c.OrganizationTypeId).HasColumnName("idOrganizationType");
        }
    }
}

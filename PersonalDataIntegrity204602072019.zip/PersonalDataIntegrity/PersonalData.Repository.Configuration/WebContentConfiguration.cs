﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using PersonalData.Repository.Models.Objects;
using System;
using System.Collections.Generic;
using System.Text;

namespace PersonalData.Repository.Configuration {

    public class WebContentConfiguration : IEntityTypeConfiguration<WebContent> {

        public void Configure(EntityTypeBuilder<WebContent> builder) {

            builder.ToTable("ftWebContent");
            builder.HasKey(c => c.Id);

            builder.HasMany(c => c.WebContentRoles).WithOne(c => c.WebContent).HasForeignKey(c => c.WebContentId).OnDelete(DeleteBehavior.Restrict);

            builder.Property(c => c.Id).IsRequired().HasColumnName("idWebContent");
            builder.Property(c => c.WebContentTypeId).HasColumnName("idWebContentType");
            builder.Property(c => c.WebContentStatusId).HasColumnName("idWebContentStatus");
            builder.Property(c => c.WebFile).HasColumnName("sFile");
            builder.Property(c => c.WebRoute).HasColumnName("sRoute");
            builder.Property(c => c.WebController).HasColumnName("sController");
            builder.Property(c => c.WebAction).HasColumnName("sAction");
        }
    }
}

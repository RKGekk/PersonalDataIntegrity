﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using PersonalData.Repository.Models.Objects;
using System;
using System.Collections.Generic;
using System.Text;

namespace PersonalData.Repository.Configuration {

    public class UserLoginConfiguration : IEntityTypeConfiguration<UserLogin> {

        public void Configure(EntityTypeBuilder<UserLogin> builder) {

            builder.ToTable("ftUserLogin");
            builder.HasKey(c => c.Id);

            builder.HasOne(c => c.Subject).WithMany(c => c.UserLogins).HasForeignKey(c => c.SubjectId).OnDelete(DeleteBehavior.Restrict);

            builder.Property(c => c.Id).IsRequired().HasColumnName("idUserLogin");
            builder.Property(c => c.SubjectId).HasColumnName("idSubject");
            builder.Property(c => c.From).HasColumnName("dFrom");
            builder.Property(c => c.Thru).HasColumnName("dThru");
            builder.Property(c => c.Login).HasColumnName("sLogin");
            builder.Property(c => c.LoginHash).HasColumnName("sLoginHash");
            builder.Property(c => c.Password).HasColumnName("sPassword");
            builder.Property(c => c.PasswordHash).HasColumnName("sPasswoerdHash");
        }
    }
}

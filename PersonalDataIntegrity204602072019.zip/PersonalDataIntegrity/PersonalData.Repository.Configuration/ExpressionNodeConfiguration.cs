﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using PersonalData.Repository.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace PersonalData.Repository.Configuration {

    public class ExpressionNodeConfiguration : IEntityTypeConfiguration<ExpressionNode> {

        public void Configure(EntityTypeBuilder<ExpressionNode> builder) {

            builder.ToTable("ftExpressionNodes");
            builder.HasKey(c => c.Id);


            builder.HasOne(c => c.Reference).WithOne(c => c.ExpressionNode).HasForeignKey<Reference>(c => c.Id).OnDelete(DeleteBehavior.Restrict);
            builder.HasOne(c => c.OperationNode).WithOne(c => c.ExpressionNode).HasForeignKey<OperationNode>(c => c.Id).OnDelete(DeleteBehavior.Restrict);
            builder.HasMany(c => c.OperationArgumentList).WithOne(c => c.ExpressionArgument).HasForeignKey(c => c.ExpressionArgumentId).OnDelete(DeleteBehavior.Restrict);
            builder.HasOne(c => c.ExpressionNodeType).WithMany(c => c.ExpressionNode_ExpressionNodeTypes).HasForeignKey(c => c.ExpressionNodeTypeId).OnDelete(DeleteBehavior.Restrict);
            

            builder.Property(c => c.Id).HasColumnName("idExpressionNode").IsRequired();
            builder.Property(c => c.ExpressionNodeTypeId).HasColumnName("idExpressionNodeType").IsRequired();
        }
    }
}

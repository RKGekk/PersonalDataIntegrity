﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using PersonalData.Repository.Models.Objects;
using System;
using System.Collections.Generic;
using System.Text;

namespace PersonalData.Repository.Configuration {

    public class WebContentRoleConfiguration : IEntityTypeConfiguration<WebContentRole> {

        public void Configure(EntityTypeBuilder<WebContentRole> builder) {

            builder.ToTable("ftWebContentRole");
            builder.HasKey(c => c.Id);

            builder.HasOne(c => c.BaseSubjectRole).WithOne(c => c.WebContentRole).OnDelete(DeleteBehavior.Restrict);
            builder.HasOne(c => c.WebContent).WithMany(c => c.WebContentRoles).HasForeignKey(c => c.WebContentId).OnDelete(DeleteBehavior.Restrict);

            builder.Property(c => c.Id).IsRequired().HasColumnName("idWebContentRole");
            builder.Property(c => c.WebContentId).HasColumnName("idWebContent");
        }
    }
}

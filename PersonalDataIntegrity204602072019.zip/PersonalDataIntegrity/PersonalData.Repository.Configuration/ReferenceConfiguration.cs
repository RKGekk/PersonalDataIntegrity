﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using PersonalData.Repository.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace PersonalData.Repository.Configuration {

    public class ReferenceConfiguration : IEntityTypeConfiguration<Reference> {

        public void Configure(EntityTypeBuilder<Reference> builder) {

            builder.ToTable("ftReferences");
            builder.HasKey(c => c.Id);

            builder.HasOne(c => c.ExpressionNode).WithOne(c => c.Reference).OnDelete(DeleteBehavior.Restrict);
            builder.HasOne(c => c.ReferenceType).WithMany(c => c.Reference_ReferenceTypes).HasForeignKey(c => c.ReferenceTypeId).OnDelete(DeleteBehavior.Restrict);
            builder.HasOne(c => c.TypeReference).WithOne(c => c.Reference).HasForeignKey<TypeReference>(c => c.Id).OnDelete(DeleteBehavior.Restrict);
            builder.HasOne(c => c.ConstReference).WithOne(c => c.Reference).HasForeignKey<ConstReference>(c => c.Id).OnDelete(DeleteBehavior.Restrict);

            builder.Property(c => c.Id).HasColumnName("idReference").IsRequired();
            builder.Property(c => c.ReferenceTypeId).HasColumnName("idReferenceType").IsRequired();
        }
    }
}

﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using PersonalData.Repository.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace PersonalData.Repository.Configuration {

    public class TypeCategoryConfiguration : IEntityTypeConfiguration<TypeCategory> {

        public void Configure(EntityTypeBuilder<TypeCategory> builder) {

            builder.ToTable("drTypeCategory");
            builder.HasKey(c => c.Id);

            builder.HasOne(c => c.TypeDigest).WithOne(c => c.TypeCategoryBase).OnDelete(DeleteBehavior.Restrict);
            builder.HasMany(c => c.TypeDigests).WithOne(c => c.Category);
            builder.HasOne(c => c.TypeTable).WithMany(c => c.TypeCategories).HasForeignKey(c => c.TypeTableId);
            
            builder.Property(c => c.Id).IsRequired().HasColumnName("idTypeCategory");
            builder.Property(c => c.TypeTableId).HasColumnName("idTypeTable");
        }
    }
}

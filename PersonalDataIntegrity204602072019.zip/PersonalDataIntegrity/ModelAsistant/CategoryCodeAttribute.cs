﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ModelAssistant {

    /// <summary>
    /// Выставляет перечислению атрибут с указанным кодом sCode.
    /// </summary>
    [AttributeUsage(AttributeTargets.Enum, Inherited = false, AllowMultiple = false)]
    public class CategoryCodeAttribute : Attribute {

        /// <summary>
        /// Initializes a new instance of the <see cref="CategoryCodeAttribute"/> class.
        /// </summary>
        /// <param name="code">Код категории.</param>
        public CategoryCodeAttribute(string code) {
            Code = code;
        }

        /// <summary>
        /// Код категории.
        /// </summary>
        public string Code { get; private set; }
    }
}

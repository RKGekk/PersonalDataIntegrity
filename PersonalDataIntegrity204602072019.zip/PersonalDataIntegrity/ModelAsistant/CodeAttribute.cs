﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ModelAssistant {

    /// <summary>
    /// Выставляет полю перечисления атрибут с указанным кодом sCode.
    /// </summary>
    [AttributeUsage(AttributeTargets.Field | AttributeTargets.Enum, Inherited = false, AllowMultiple = false)]
    public class CodeAttribute : Attribute {

        /// <summary>
        /// Initializes a new instance of the <see cref="CodeAttribute"/> class.
        /// </summary>
        /// <param name="code">Код категории.</param>
        public CodeAttribute(string code) {
            Code = code;
        }

        /// <summary>
        /// Код типа.
        /// </summary>
        public string Code { get; private set; }
    }
}

﻿using System;
using System.IO;

namespace ModelAssistant {

    public interface IDataFormatter<T> {

        T Deserialize(Stream serializationStream);
        T Deserialize(string stringToDeserialize);

        void Serialize(Stream serializationStream, T objectToSerialize);
        string Serialize(T objectToSerialize);
    }
}

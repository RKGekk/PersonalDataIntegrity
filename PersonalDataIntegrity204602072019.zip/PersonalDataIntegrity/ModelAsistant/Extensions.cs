﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Runtime.Serialization;
using System.Text;

namespace ModelAssistant {

    public static class Extensions {

        /// <summary>
        /// Получить по значению перечисления код (из атрибута CodeAttribute)
        /// </summary>
        /// <param name="ent"></param>
        /// <returns></returns>
        public static string GetRepositoryCode(this Enum enumType) {

            Type type = enumType.GetType();
            MemberInfo[] memInfo = type.GetMember(enumType.ToString());
            CodeAttribute codeAttribute = memInfo[0].GetCustomAttributes<CodeAttribute>(false).FirstOrDefault();

            if (codeAttribute != null) {
                return codeAttribute.Code;
            }
            else {
                throw new ArgumentException($"Поле {enumType.ToString()} перечисления {enumType.GetType().Name} не содержит атрибута {nameof(CodeAttribute)}");
            }
        }

        /// <summary>
        /// Получить по значению перечисления код (из атрибута CodeAttribute)
        /// </summary>
        /// <param name="ent"></param>
        /// <returns></returns>
        public static string GetServiceCode(this Enum enumType) {

            Type type = enumType.GetType();
            MemberInfo[] memInfo = type.GetMember(enumType.ToString());
            EnumMemberAttribute codeAttribute = memInfo[0].GetCustomAttributes<EnumMemberAttribute>(false).FirstOrDefault();

            if (codeAttribute != null) {
                return codeAttribute.Value;
            }
            else {
                throw new ArgumentException($"Поле {enumType.ToString()} перечисления {enumType.GetType().Name} не содержит атрибута {nameof(CodeAttribute)}");
            }
        }

        public static string GetRepositoryCategoryCode<T>() where T : struct, IConvertible {
            CategoryCodeAttribute attr = Attribute.GetCustomAttribute(typeof(T), typeof(CategoryCodeAttribute)) as CategoryCodeAttribute;

            if (attr == null) {
                throw new CustomAttributeFormatException($"Не удалось извлечь атрибут {nameof(CategoryCodeAttribute)} из типа {typeof(T).Name}");
            }
            else {
                return attr.Code;
            }
        }

        public static string GetRepositoryCode<T>() where T : struct, IConvertible {
            CodeAttribute attr = Attribute.GetCustomAttribute(typeof(T), typeof(CodeAttribute)) as CodeAttribute;

            if (attr == null) {
                throw new CustomAttributeFormatException($"Не удалось извлечь атрибут {nameof(CodeAttribute)} из типа {typeof(T).Name}");
            }
            else {
                return attr.Code;
            }
        }

        public static string GetRepositoryCategoryCode(this Enum categoryCodeAttribute) {
            CategoryCodeAttribute attr = Attribute.GetCustomAttribute(categoryCodeAttribute.GetType(), typeof(CategoryCodeAttribute)) as CategoryCodeAttribute;

            if (attr == null) {
                throw new CustomAttributeFormatException($"Не удалось извлечь атрибут {nameof(CategoryCodeAttribute)} из типа {categoryCodeAttribute.GetType().Name}");
            }
            else {
                return attr.Code;
            }
        }

        public static T GetRepositoryEnum<T>(this string code) where T : struct, IConvertible {

            IEnumerable<T> values = Enum.GetValues(typeof(T)).Cast<T>();

            foreach (T ent in values) {
                Type t = ent.GetType();
                MemberInfo[] memInfo = t.GetMember(ent.ToString());
                CodeAttribute codeAttribute = memInfo[0].GetCustomAttributes<CodeAttribute>(false).FirstOrDefault();

                if (codeAttribute != null && code == codeAttribute.Code) {
                    return ent;
                }
            }

            throw new ArgumentOutOfRangeException(nameof(code), $"Не удалось определить значение перечисления {typeof(T).Name} для sCode = '{code}'");
        }

        public static T GetServiceEnum<T>(this string code) where T : struct, IConvertible {

            IEnumerable<T> values = Enum.GetValues(typeof(T)).Cast<T>();

            foreach (T ent in values) {
                Type t = ent.GetType();
                MemberInfo[] memInfo = t.GetMember(ent.ToString());
                EnumMemberAttribute codeAttribute = memInfo[0].GetCustomAttributes<EnumMemberAttribute>(false).FirstOrDefault();

                if (codeAttribute != null && code == codeAttribute.Value) {
                    return ent;
                }
            }

            throw new ArgumentOutOfRangeException(nameof(code), $"Не удалось определить значение перечисления {typeof(T).Name} для sCode = '{code}'");
        }

        public static R Using<T, R>(this T item, Func<T, R> func) where T : IDisposable {
            using (item) {
                return func(item);
            }
        }

        public static Func<A, Func<B, R>> Curry<A, B, R>(this Func<A, B, R> function) {
            return a => b => function(a, b);
        }

        public static Func<A, B, R> UnCurry<A, B, R>(this Func<A, Func<B, R>> function) {
            return (a, b) => function(a)(b);
        }

        public static Func<B, R> Partial<A, B, R>(this Func<A, B, R> function, A argument1) {
            return argument2 => function(argument1, argument2);
        }

        public static T Retry<T>(this Func<T> function) {

            int retry = 0;
            T result = default(T);
            bool success = false;
            do {
                try {
                    result = function();
                    success = true;
                }
                catch {
                    retry++;
                }
            } while (!success && retry < 3);

            return result;
        }
    }
}

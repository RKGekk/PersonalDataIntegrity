﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PersonalData.Repository.Models.Objects {

    /// <summary>
    /// Организация объектов которые могут управлять системой
    /// </summary>
    public class Organization {

        /// <summary>
        /// ID организации
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// ID тип организации
        /// </summary>
        public int OrganizationTypeId { get; set; }

        /// <summary>
        /// Базовый субъект
        /// </summary>
        public virtual Subject BaseSubject { get; set; }

        /// <summary>
        /// Тип Организации
        /// </summary>
        public virtual TypeDigest OrganizationType { get; set; }
    }
}

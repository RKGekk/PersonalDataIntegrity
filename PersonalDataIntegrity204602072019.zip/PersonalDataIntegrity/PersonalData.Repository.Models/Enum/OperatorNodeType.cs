﻿using ModelAssistant;
using System;
using System.Collections.Generic;
using System.Text;

namespace PersonalData.Repository.Models.Enum {

    /// <summary>
    /// Перечисление типов операций
    /// </summary>
    public enum OperatorNodeType {

        /// <summary>
        /// Оператор плюс.
        /// </summary>
        [Code("OperatorPlusNode")]
        Plus = 1,

        /// <summary>
        /// Оператор минус.
        /// </summary>
        [Code("OperatorMinusNode")]
        Minus = 2,

        /// <summary>
        /// Оператор умножить.
        /// </summary>
        [Code("OperatorMultiplyNode")]
        Multiply = 3,

        /// <summary>
        /// Оператор разделить.
        /// </summary>
        [Code("OperatorDivideNode")]
        Divide = 4,

        /// <summary>
        /// Оператор присвоения.
        /// </summary>
        [Code("OperatorAssignNode")]
        Assign = 5,

        /// <summary>
        /// Оператор если.
        /// </summary>
        [Code("OperatorIfNode")]
        If = 6,

        /// <summary>
        /// Оператор сравнения.
        /// </summary>
        [Code("OperatorEqualNode")]
        Equal = 7
    }
}

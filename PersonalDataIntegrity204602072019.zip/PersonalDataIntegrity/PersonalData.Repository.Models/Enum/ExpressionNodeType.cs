﻿using ModelAssistant;
using System;
using System.Collections.Generic;
using System.Text;

namespace PersonalData.Repository.Models.Enum {

    /// <summary>
    /// Перечисление типов узлов выражений.
    /// </summary>
    public enum ExpressionNodeType {

        /// <summary>
        /// Ссылка
        /// </summary>
        [Code("ReferenceExpressionNode")]
        Reference = 0,

        /// <summary>
        /// Оператор.
        /// </summary>
        [Code("OperatorExpressionNode")]
        Operator = 1
    }
}

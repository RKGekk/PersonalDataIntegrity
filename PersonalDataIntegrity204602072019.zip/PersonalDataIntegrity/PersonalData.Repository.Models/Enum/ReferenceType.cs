﻿using ModelAssistant;
using System;
using System.Collections.Generic;
using System.Text;

namespace PersonalData.Repository.Models.Enum {

    /// <summary>
    /// Перечисление вида ссылки в формуле.
    /// </summary>
    public enum ReferenceType {

        /// <summary>
        /// Ссылка на тип.
        /// </summary>
        [Code("TypeReference")]
        Type = 0,

        /// <summary>
        /// Ссылка на действие.
        /// </summary>
        [Code("ActReference")]
        Act = 1,

        /// <summary>
        /// Ссылка на константу.
        /// </summary>
        [Code("ConstReference")]
        Const = 2
    }
}

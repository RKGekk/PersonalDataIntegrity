﻿using ModelAssistant;
using System;
using System.Collections.Generic;
using System.Text;

namespace PersonalData.Repository.Models.Enum {

    /// <summary>
    /// Перечисление типов констант.
    /// </summary>
    public enum ConstReferenceType {

        /// <summary>
        /// Указатель на константу-строку.
        /// </summary>
        [Code("StringConstReference")]
        String = 0,

        /// <summary>
        /// Указатель на константу-целое число.
        /// </summary>
        [Code("IntConstReference")]
        Int = 1,

        /// <summary>
        /// Указатель на константу-число с плавающей точкой
        /// </summary>
        [Code("FloatConstReference")]
        Float = 2,

        /// <summary>
        /// Указатель на константу-логическое значение
        /// </summary>
        [Code("BoolConstReference")]
        Bool = 3
    }
}

﻿//using PersonalData.Repository.Models.Objects;
using System;
using System.Collections.Generic;
using System.Text;

namespace PersonalData.Repository.Models {

    public interface IPersonalData_Repository {

    }
}

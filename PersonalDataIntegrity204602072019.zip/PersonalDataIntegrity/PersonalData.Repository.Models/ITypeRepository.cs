﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PersonalData.Repository.Models {

    /// <summary>
    /// 
    /// </summary>
    public interface ITypeRepository {

        /// <summary>
        /// Плучить все ноды для выражений.
        /// </summary>
        /// <returns>Список узлов выражений.</returns>
        IList<ExpressionNode> GetExpressionNodes();

        /// <summary>
        /// Плучить все ссылки на данные для выражений.
        /// </summary>
        /// <returns>Список ссылок.</returns>
        IList<Reference> GetReferences();

        /// <summary>
        /// Получить все ссылки на данные из таблицы с типами.
        /// </summary>
        /// <param name="id">Идентификатор типа ссылки.</param>
        /// <returns>Список ссылок на данные из таблицы с типами.</returns>
        TypeReference GetTypeReference(int id);

        /// <summary>
        /// Получить все ссылки на данные из таблицы с константами.
        /// </summary>
        /// <returns>Список ссылок на данные из таблицы с константами.</returns>
        IList<ConstReference> GetConstReferences();

        /// <summary>
        /// Получить все ссылки на данные из таблицы с указателями на типы.
        /// </summary>
        /// <returns>Перечисление типов ссылок.</returns>
        IList<TypeReference> GetTypeReferences();

        /// <summary>
        /// Получить все данные из таблицы с операторами.
        /// </summary>
        /// <returns>Перечисление операций.</returns>
        IList<OperationNode> GetOperationNodes();

        /// <summary>
        /// Получить все операторы присвоения.
        /// </summary>
        /// <returns>Перечисление операторов присвоения.</returns>
        IList<OperationNode> GetAssignOperationNodes();

        /// <summary>
        /// Получить все данные из таблицы со связями операторов и операндов.
        /// </summary>
        /// <returns>Перечисление аргументов операций.</returns>
        IList<OperationArgumentList> GetOperationArgumentLists();

        /// <summary>
        /// Получить один тип по id.
        /// </summary>
        /// <param name="idType">Идентификатор типа.</param>
        /// <returns>Тип.</returns>
        TypeDigest GetModelType(int idType);

        /// <summary>
        /// Получить один тип по коду.
        /// </summary>
        /// <param name="code">Код типа.</param>
        /// <returns>Тип.</returns>
        TypeDigest GetModelType(string code);

        /// <summary>
        /// Получить типы по коду категории.
        /// </summary>
        /// <param name="code">Код типа.</param>
        /// <returns>Перечисление типов.</returns>
        List<TypeDigest> GetTypesByCategoryCode(string code);
    }
}

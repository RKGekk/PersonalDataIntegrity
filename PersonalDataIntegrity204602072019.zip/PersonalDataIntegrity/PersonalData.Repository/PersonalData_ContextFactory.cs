﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using System;
using System.Collections.Generic;
using System.Text;

namespace PersonalData.Repository {

    public class PersonalData_ContextFactory : IDesignTimeDbContextFactory<PersonalData_Context> {

        private const string _connectionName = "PersonalData_Connection";
        //private const string _connectionString = @"Server=(localdb)\mssqllocaldb; Database=MyFirstEfCoreDb; Trusted_Connection=True";
        private const string _connectionString = @"Data Source=DESKTOP-DNGLLUO; Initial Catalog=PersonalData; Integrated Security=True";
        //private const string _connectionString = @"Data Source=A110163; Initial Catalog=PersonalData; Integrated Security=True";

        public PersonalData_Context CreateDbContext(string[] args) {

            var optionsBuilder = new DbContextOptionsBuilder<PersonalData_Context>();
            optionsBuilder.UseSqlServer(_connectionString);

            return new PersonalData_Context(optionsBuilder.Options);
        }
    }
}

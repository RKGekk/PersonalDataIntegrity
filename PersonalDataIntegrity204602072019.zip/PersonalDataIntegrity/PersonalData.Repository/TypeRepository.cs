﻿using ModelAssistant;
using System.Runtime.Caching;
using PersonalData.Repository.Models;
using PersonalData.Repository.Models.Enum;
using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using Microsoft.EntityFrameworkCore;
using System.Linq;

namespace PersonalData.Repository {

    public class TypeRepository : ITypeRepository {

        private static readonly ObjectCache _cacheTypes = new MemoryCache(nameof(TypeDigest));
        private static readonly ObjectCache _cacheTypeReferences = new MemoryCache(nameof(TypeReference));
        private static readonly ObjectCache _cacheList = new MemoryCache(nameof(ICollection));

        /// <summary>
        /// Задае время жизни объекта в кэше
        /// </summary>
        private DateTimeOffset ExpirationTimeCacheEntry {
            get {
                int expirationCache = 1;
                return new DateTimeOffset(DateTime.Now.AddMinutes(expirationCache));
            }
        }

        /// <summary>
        /// Получить все ссылки на данные из таблицы с константами.
        /// </summary>
        /// <returns>Список ссылок на данные из таблицы с константами.</returns>
        public IList<ConstReference> GetConstReferences() {

            string hash = System.Reflection.MethodBase.GetCurrentMethod().Name;
            IList<ConstReference> result = _cacheList.Get(hash) as IList<ConstReference>;

            if (result == null) {
                PersonalData_ContextFactory r_ContextFactory = new PersonalData_ContextFactory();
                using (PersonalData_Context context = r_ContextFactory.CreateDbContext(null)) {
                    result = context.ConstReferences.AsNoTracking().ToList();
                }

                if (result != null) {
                    _cacheList.Set(hash, result, ExpirationTimeCacheEntry);
                }
            }

            return result;
        }

        /// <summary>
        /// Плучить все ноды для выражений.
        /// </summary>
        /// <returns>Список узлов выражений.</returns>
        public IList<ExpressionNode> GetExpressionNodes() {

            string hash = System.Reflection.MethodBase.GetCurrentMethod().Name;
            IList<ExpressionNode> result = _cacheList.Get(hash) as IList<ExpressionNode>;

            if (result == null) {
                PersonalData_ContextFactory r_ContextFactory = new PersonalData_ContextFactory();
                using (PersonalData_Context context = r_ContextFactory.CreateDbContext(null)) {
                    result = context.ExpressionNodes.AsNoTracking().ToList();
                }

                if (result != null) {
                    _cacheList.Set(hash, result, ExpirationTimeCacheEntry);
                }
            }

            return result;
        }

        public IList<OperationArgumentList> GetOperationArgumentLists() {

            string hash = System.Reflection.MethodBase.GetCurrentMethod().Name;
            IList<OperationArgumentList> result = _cacheList.Get(hash) as IList<OperationArgumentList>;

            if (result == null) {
                PersonalData_ContextFactory r_ContextFactory = new PersonalData_ContextFactory();
                using (PersonalData_Context context = r_ContextFactory.CreateDbContext(null)) {
                    result = context.OperationArgumentLists.AsNoTracking().ToList();
                }

                if (result != null)
                    _cacheList.Set(hash, result, ExpirationTimeCacheEntry);
            }

            return result;
        }

        public IList<OperationNode> GetOperationNodes() {

            string hash = System.Reflection.MethodBase.GetCurrentMethod().Name;
            IList<OperationNode> result = _cacheList.Get(hash) as IList<OperationNode>;

            if (result == null) {
                PersonalData_ContextFactory r_ContextFactory = new PersonalData_ContextFactory();
                using (PersonalData_Context context = r_ContextFactory.CreateDbContext(null)) {
                    result = context.OperationNodes.AsNoTracking().ToList();
                }

                if (result != null)
                    _cacheList.Set(hash, result, ExpirationTimeCacheEntry);
            }

            return result;
        }

        public IList<Reference> GetReferences() {

            string hash = System.Reflection.MethodBase.GetCurrentMethod().Name;
            IList<Reference> result = _cacheList.Get(hash) as IList<Reference>;

            if (result == null) {
                PersonalData_ContextFactory r_ContextFactory = new PersonalData_ContextFactory();
                using (PersonalData_Context context = r_ContextFactory.CreateDbContext(null)) {
                    result = context.References.AsNoTracking().ToList();
                }

                if (result != null)
                    _cacheList.Set(hash, result, ExpirationTimeCacheEntry);
            }

            return result;
        }

        public TypeDigest GetModelType(int idType) {

            string hash = idType.GetHashCode().ToString();
            TypeDigest result = _cacheTypes.Get(hash) as TypeDigest;

            if (result == null) {
                PersonalData_ContextFactory r_ContextFactory = new PersonalData_ContextFactory();
                using (PersonalData_Context context = r_ContextFactory.CreateDbContext(null)) {
                    result = context.TypeDigests.AsNoTracking().Where(t => t.Id == idType).FirstOrDefault();
                }

                if (result != null)
                    _cacheTypes.Set(hash, result, ExpirationTimeCacheEntry);
            }

            return result;
        }

        public TypeDigest GetModelType(string code) {

            string hash = code.GetHashCode().ToString();

            TypeDigest result = _cacheTypes.Get(hash) as TypeDigest;

            if (result == null) {
                PersonalData_ContextFactory r_ContextFactory = new PersonalData_ContextFactory();
                using (PersonalData_Context context = r_ContextFactory.CreateDbContext(null)) {
                    result = context.TypeDigests.AsNoTracking().Where(t => t.Code == code).FirstOrDefault();
                }

                if (result != null)
                    _cacheTypes.Set(hash, result, ExpirationTimeCacheEntry);
            }

            return result;
        }

        public TypeReference GetTypeReference(int id) {

            string hash = id.GetHashCode().ToString();
            TypeReference result = _cacheTypeReferences.Get(hash) as TypeReference;

            if (result == null) {
                PersonalData_ContextFactory r_ContextFactory = new PersonalData_ContextFactory();
                using (PersonalData_Context context = r_ContextFactory.CreateDbContext(null)) {
                    result = context.TypeReferences.AsNoTracking().Where(p => p.Id == id).FirstOrDefault();
                }

                if (result != null)
                    _cacheTypeReferences.Set(hash, result, ExpirationTimeCacheEntry);
            }

            return result;
        }

        public List<TypeDigest> GetTypesByCategoryCode(string code) {

            List<TypeDigest> result;

            PersonalData_ContextFactory r_ContextFactory = new PersonalData_ContextFactory();
            using (PersonalData_Context context = r_ContextFactory.CreateDbContext(null)) {
                result = context.TypeDigests.AsNoTracking().Where(t => t.Category.TypeDigest.Code == code).ToList();
            }

            return result;
        }

        public IList<TypeReference> GetTypeReferences() {

            string hash = System.Reflection.MethodBase.GetCurrentMethod().Name;
            IList<TypeReference> result = _cacheList.Get(hash) as IList<TypeReference>;

            if (result == null) {
                PersonalData_ContextFactory r_ContextFactory = new PersonalData_ContextFactory();
                using (PersonalData_Context context = r_ContextFactory.CreateDbContext(null)) {
                    result = context.TypeReferences.AsNoTracking().ToList();
                }

                if (result != null)
                    _cacheList.Set(hash, result, ExpirationTimeCacheEntry);
            }

            return result;
        }

        public IList<OperationNode> GetAssignOperationNodes() {

            IList<OperationNode> result;

            PersonalData_ContextFactory r_ContextFactory = new PersonalData_ContextFactory();
            using (PersonalData_Context context = r_ContextFactory.CreateDbContext(null)) {
                int idType_AssignNode = GetModelType(Extensions.GetRepositoryCode(PersonalData.Repository.Models.Enum.OperatorNodeType.Assign)).Id;
                result = context.OperationNodes.AsNoTracking().Where(o => o.OperationNodeTypeId == idType_AssignNode).ToList();
            }

            return result;
        }
    }
}

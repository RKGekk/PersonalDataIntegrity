﻿using PersonalData.Repository.Models;
//using PersonalData.Repository.Models.Objects;
using System;
using System.Collections.Generic;
using System.Text;

namespace PersonalData.Repository {

    public class PersonalData_Repository : IPersonalData_Repository {

    }
}

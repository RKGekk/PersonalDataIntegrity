﻿using Microsoft.EntityFrameworkCore;
using PersonalData.Repository.Configuration;
using PersonalData.Repository.Models;
//using PersonalData.Repository.Models.Objects;
using System;
using System.Collections.Generic;
using System.Text;

namespace PersonalData.Repository {

    public class PersonalData_Context : DbContext {

        public PersonalData_Context(DbContextOptions<PersonalData_Context> options) : base(options) { }

        public DbSet<ConstReference> ConstReferences { get; set; }
        public DbSet<ExpressionNode> ExpressionNodes { get; set; }
        public DbSet<OperationArgumentList> OperationArgumentLists { get; set; }
        public DbSet<OperationNode> OperationNodes { get; set; }
        public DbSet<Reference> References { get; set; }
        public DbSet<TypeCategory> TypeCategories { get; set; }
        public DbSet<TypeDigest> TypeDigests { get; set; }
        public DbSet<TypeReference> TypeReferences { get; set; }
        public DbSet<TypeTable> TypeTables { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder) {

        }

        protected override void OnModelCreating(ModelBuilder modelBuilder) {

            modelBuilder.ApplyConfiguration(new TypeDigestConfiguraion());
            modelBuilder.ApplyConfiguration(new TypeCategoryConfiguration());
            modelBuilder.ApplyConfiguration(new TypeTableConfiguration());

            modelBuilder.ApplyConfiguration(new TypeDigestRelationConfiguration());
            modelBuilder.ApplyConfiguration(new TypeReferenceConfiguration());
            modelBuilder.ApplyConfiguration(new ConstReferenceConfiguration());
            modelBuilder.ApplyConfiguration(new ExpressionNodeConfiguration());
            modelBuilder.ApplyConfiguration(new OperationArgumentListConfig());
            modelBuilder.ApplyConfiguration(new OperationNodeConfiguration());
            modelBuilder.ApplyConfiguration(new ReferenceConfiguration());

            modelBuilder.ApplyConfiguration(new DocumentSubjectConfiguration());
            modelBuilder.ApplyConfiguration(new IdentityDocumentConfiguration());
            modelBuilder.ApplyConfiguration(new UserLoginConfiguration());
            modelBuilder.ApplyConfiguration(new WebContentConfiguration());
            modelBuilder.ApplyConfiguration(new WebContentRoleConfiguration());
            modelBuilder.ApplyConfiguration(new SubjectRoleConfiguration());
            modelBuilder.ApplyConfiguration(new RoleRelationConfiguration());
            modelBuilder.ApplyConfiguration(new SubjectConfiguration());
            modelBuilder.ApplyConfiguration(new SubjectNameConfiguration());
            modelBuilder.ApplyConfiguration(new OrganizationConfiguration());
            modelBuilder.ApplyConfiguration(new PersonConfiguration());
            modelBuilder.ApplyConfiguration(new MaritalStatusConfiguration());
            modelBuilder.ApplyConfiguration(new GenderConfiguration());
            modelBuilder.ApplyConfiguration(new PhysicalCharacteristicConfiguration());
        }
    }
}
